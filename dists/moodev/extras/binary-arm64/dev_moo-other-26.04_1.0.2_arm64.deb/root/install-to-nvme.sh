#!/bin/bash
set -e

# Target Variables for NVMe
TARGET_DEV="/dev/nvme0n1"
ROOTPART="${TARGET_DEV}p1"
MOUNTDIR="/mnt/nvme"

# Ensure script is run as root
if [ "$EUID" -ne 0 ]; then 
  echo "Please run as root"
  exit 1
fi

# Unmount anything stale
umount ${TARGET_DEV}* 2>/dev/null || true

# Partition
wipefs -a "$TARGET_DEV" >/dev/null 2>&1
parted -s "$TARGET_DEV" mklabel gpt >/dev/null 2>&1
parted -s "$TARGET_DEV" mkpart primary ext4 0% 100% >/dev/null 2>&1
partprobe "$TARGET_DEV" >/dev/null 2>&1
sleep 1

# Format
mkfs.ext4 -qF "$ROOTPART" >/dev/null 2>&1

# Mount
mkdir -p "$MOUNTDIR"
mount "$ROOTPART" "$MOUNTDIR"

# Copy
rsync -aqxHAX / "$MOUNTDIR" \
    --exclude="/dev/*" \
    --exclude="/proc/*" \
    --exclude="/sys/*" \
    --exclude="/tmp/*" \
    --exclude="/run/*" \
    --exclude="/mnt/*" \
    --exclude="/media/*" \
    --exclude="/lost+found"

# Fix UUIDs
NEWUUID=$(blkid -s UUID -o value "$ROOTPART")

sed -i "s/^rootdev=.*/rootdev=UUID=$NEWUUID/" "$MOUNTDIR/boot/armbianEnv.txt"
grep -q "^rootdev" "$MOUNTDIR/boot/armbianEnv.txt" || echo "rootdev=UUID=$NEWUUID" >> "$MOUNTDIR/boot/armbianEnv.txt"

sed -i "s/^rootfstype=.*/rootfstype=ext4/" "$MOUNTDIR/boot/armbianEnv.txt"
grep -q "^rootfstype" "$MOUNTDIR/boot/armbianEnv.txt" || echo "rootfstype=ext4" >> "$MOUNTDIR/boot/armbianEnv.txt"

cat > "$MOUNTDIR/etc/fstab" <<EOF
UUID=$NEWUUID / ext4 defaults,noatime,commit=120,errors=remount-ro 0 1
tmpfs /tmp tmpfs defaults,nosuid 0 0
EOF

# Done
umount "$MOUNTDIR"
exit 0
