#!/bin/bash
set -e

EMMC="/dev/mmcblk0"
ROOTPART="${EMMC}p1"
MOUNTDIR="/mnt/emmc"

# unmount anything stale
umount ${EMMC}* 2>/dev/null || true

# partition
wipefs -a "$EMMC" >/dev/null 2>&1
parted -s "$EMMC" mklabel gpt >/dev/null 2>&1
parted -s "$EMMC" mkpart primary ext4 0% 100% >/dev/null 2>&1
partprobe "$EMMC" >/dev/null 2>&1
sleep 1

# format
mkfs.ext4 -qF "$ROOTPART" >/dev/null 2>&1

# mount
mkdir -p "$MOUNTDIR"
mount "$ROOTPART" "$MOUNTDIR"

# copy
rsync -aqxHAX / "$MOUNTDIR" \
    --exclude="/dev/*" \
    --exclude="/proc/*" \
    --exclude="/sys/*" \
    --exclude="/tmp/*" \
    --exclude="/run/*" \
    --exclude="/mnt/*" \
    --exclude="/media/*" \
    --exclude="/lost+found"

# fix UUIDs
NEWUUID=$(blkid -s UUID -o value "$ROOTPART")

sed -i "s/^rootdev=.*/rootdev=UUID=$NEWUUID/" "$MOUNTDIR/boot/armbianEnv.txt"
grep -q "^rootdev" "$MOUNTDIR/boot/armbianEnv.txt" || echo "rootdev=UUID=$NEWUUID" >> "$MOUNTDIR/boot/armbianEnv.txt"

sed -i "s/^rootfstype=.*/rootfstype=ext4/" "$MOUNTDIR/boot/armbianEnv.txt"
grep -q "^rootfstype" "$MOUNTDIR/boot/armbianEnv.txt" || echo "rootfstype=ext4" >> "$MOUNTDIR/boot/armbianEnv.txt"

cat > "$MOUNTDIR/etc/fstab" <<EOF
UUID=$NEWUUID / ext4 defaults,noatime,commit=120,errors=remount-ro 0 1
tmpfs /tmp tmpfs defaults,nosuid 0 0
EOF

# done
umount "$MOUNTDIR"
exit 0
