console.log("loading global.js ...");
/* hide asap dont wait for render */
// we are using the standard loading of signalr since its nice since .net core 10
//document.getElementById("loadingbox").hidden = true

window.SetThemeContrast = async (contrastValue) => {
  document.documentElement.style.filter = `contrast(${contrastValue})`;
  document.body.style.filter = `contrast(${contrastValue})`;
};