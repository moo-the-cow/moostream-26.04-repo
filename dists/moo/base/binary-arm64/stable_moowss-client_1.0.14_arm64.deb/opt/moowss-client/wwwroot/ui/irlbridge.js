// Setup software tabs navigation
window.setupSoftwareTabs = async () => {
    const softwareTabs = document.querySelectorAll('.software-tab');
    const softwareContents = document.querySelectorAll('.software-content');
    
    softwareTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const software = tab.dataset.software;
            
            // Remove active class from all tabs and contents
            softwareTabs.forEach(t => t.classList.remove('active'));
            softwareContents.forEach(c => c.classList.remove('active'));
            
            // Add active class to clicked tab and corresponding content
            tab.classList.add('active');
            document.getElementById(`${software}-content`).classList.add('active');
        });
    });
}
// Tab navigation
window.setupTabNavigation = async () => {
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const tabId = btn.dataset.tab;
            
            // Remove active class from all tabs and contents
            tabBtns.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            
            // Add active class to clicked tab and corresponding content
            btn.classList.add('active');
            document.getElementById(`${tabId}-config`).classList.add('active');
        });
    });
}

// Toggle password visibility
window.togglePassword = async () => {
    const passwordInput = document.getElementById('wifi-password');
    const toggleBtn = document.querySelector('.toggle-password');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleBtn.textContent = '🙈';
    } else {
        passwordInput.type = 'password';
        toggleBtn.textContent = '👁️';
    }
}

window.setAudioActive = async (element) => {
    //reset others
    document.querySelectorAll('.volume-presets .preset-btn').forEach(btn => {
        btn.classList.remove("active");
    });
    element.classList.add("active");
}

//#region Spinner
window.SpinnerLoadingAnimation = (selector, loadingText, deactivateElement = false) => {
  const element = document.querySelector(selector);
  
  if (element && !element.classList.contains("clicked")) {
    // Remove existing content
    element.textContent = '';
    
    // Create and append spinner
    const spinner = document.createElement('span');
    spinner.className = 'spinner-border spinner-border-sm';
    spinner.setAttribute('role', 'status');
    spinner.setAttribute('aria-hidden', 'true');
    
    element.appendChild(spinner);
    element.appendChild(document.createTextNode(loadingText));
    
    if (deactivateElement) {
      element.disabled = true;
    }
  }
};

window.SpinnerUnLoadingAnimation = (selector, originalText, deactivateElement = false) => {
  const element = document.querySelector(selector);
  
  if (element) {
    // Remove all child elements
    while (element.firstChild) {
      element.removeChild(element.firstChild);
    }
    
    // Set text content
    element.textContent = originalText;
    
    if (deactivateElement) {
      element.disabled = false;
    }
  }
};
//#endregion

/*
// IRLbridge Dashboard JavaScript
let currentConfig = {
    rtmp: {
        url: 'rtmp://192.168.1.100:1935/live',
        key: 'irlbridge-stream-001',
        port: 1935
    },
    srt: {
        url: 'srt://192.168.1.100:9998',
        latency: 200,
        passphrase: ''
    },
    wifi: {
        ssid: 'IRLbridge-AP',
        password: 'streaming123',
        channel: 6
    }
};

// Initialize dashboard on load
document.addEventListener('DOMContentLoaded', function() {
    loadConfig();
    generateQRCodes();
    updateSystemStatus();
    setupTabNavigation();
    setupSoftwareTabs();
    
    // Update uptime every minute
    setInterval(updateUptime, 60000);
    
    // Update system status every 5 seconds
    setInterval(updateSystemStatus, 5000);
});

// Load configuration from localStorage
function loadConfig() {
    const saved = localStorage.getItem('irlbridge-config');
    if (saved) {
        currentConfig = { ...currentConfig, ...JSON.parse(saved) };
        updateFormValues();
    }
}

// Save configuration to localStorage
function saveConfig() {
    localStorage.setItem('irlbridge-config', JSON.stringify(currentConfig));
}

// Update form values with current config
function updateFormValues() {
    document.getElementById('rtmp-url').value = currentConfig.rtmp.url;
    document.getElementById('rtmp-key').value = currentConfig.rtmp.key;
    document.getElementById('rtmp-port').value = currentConfig.rtmp.port;
    
    document.getElementById('srt-url').value = currentConfig.srt.url;
    document.getElementById('srt-latency').value = currentConfig.srt.latency;
    document.getElementById('srt-passphrase').value = currentConfig.srt.passphrase;
    
    document.getElementById('wifi-ssid').value = currentConfig.wifi.ssid;
    document.getElementById('wifi-password').value = currentConfig.wifi.password;
    document.getElementById('wifi-channel').value = currentConfig.wifi.channel;
}

// Generate QR codes for streaming software
function generateQRCodes() {
    const deviceIP = document.getElementById('device-ip').textContent;
    
    // Moblin configuration URL (mock)
    const moblinConfig = {
        server: currentConfig.rtmp.url,
        key: currentConfig.rtmp.key,
        preset: 'mobile'
    };
    const moblinURL = `moblin://setup?${new URLSearchParams(moblinConfig).toString()}`;
    
    // IRL Pro configuration URL (mock)
    const irlproConfig = {
        server: currentConfig.rtmp.url,
        key: currentConfig.rtmp.key,
        quality: 'high'
    };
    const irlproURL = `irlpro://setup?${new URLSearchParams(irlproConfig).toString()}`;
    
    // Generate QR codes using qr-server.com API
    generateQRCode('moblin-qr', moblinURL);
    generateQRCode('irlpro-qr', irlproURL);
}

// Generate individual QR code
function generateQRCode(elementId, data) {
    const qrElement = document.getElementById(elementId);
    const qrURL = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(data)}&bgcolor=ffffff&color=000000`;
    
    qrElement.innerHTML = `<img src="${qrURL}" alt="QR Code" />`;
}

// Update stream configuration
function updateStreamConfig() {
    // Get current active tab
    const activeTab = document.querySelector('.tab-btn.active').dataset.tab;
    
    if (activeTab === 'rtmp') {
        currentConfig.rtmp.url = document.getElementById('rtmp-url').value;
        currentConfig.rtmp.key = document.getElementById('rtmp-key').value;
        currentConfig.rtmp.port = parseInt(document.getElementById('rtmp-port').value);
    } else if (activeTab === 'srt') {
        currentConfig.srt.url = document.getElementById('srt-url').value;
        currentConfig.srt.latency = parseInt(document.getElementById('srt-latency').value);
        currentConfig.srt.passphrase = document.getElementById('srt-passphrase').value;
    }
    
    saveConfig();
    generateQRCodes();
    showNotification('Stream configuration updated successfully!');
}

// Update WiFi configuration
function updateWiFiConfig() {
    currentConfig.wifi.ssid = document.getElementById('wifi-ssid').value;
    currentConfig.wifi.password = document.getElementById('wifi-password').value;
    currentConfig.wifi.channel = parseInt(document.getElementById('wifi-channel').value);
    
    saveConfig();
    showNotification('WiFi configuration updated! Device will restart in 10 seconds.');
    
    // Simulate device restart countdown
    let countdown = 10;
    const interval = setInterval(() => {
        countdown--;
        if (countdown > 0) {
            showNotification(`WiFi updating... Restart in ${countdown} seconds`);
        } else {
            clearInterval(interval);
            showNotification('WiFi configuration applied successfully!');
        }
    }, 1000);
}

// Reset device
function resetDevice() {
    if (confirm('Are you sure you want to reset the device to factory settings? This will erase all custom configurations.')) {
        // Reset to default config
        currentConfig = {
            rtmp: {
                url: 'rtmp://192.168.1.100:1935/live',
                key: 'irlbridge-stream-001',
                port: 1935
            },
            srt: {
                url: 'srt://192.168.1.100:9998',
                latency: 200,
                passphrase: ''
            },
            wifi: {
                ssid: 'IRLbridge-AP',
                password: 'streaming123',
                channel: 6
            }
        };
        
        localStorage.removeItem('irlbridge-config');
        updateFormValues();
        generateQRCodes();
        showNotification('Device reset to factory settings');
    }
}

// Show notification
function showNotification(message) {
    const notification = document.getElementById('notification');
    notification.textContent = message;
    notification.classList.add('show');
    
    setTimeout(() => {
        notification.classList.remove('show');
    }, 3000);
}

// Update uptime display
function updateUptime() {
    const uptimeElement = document.getElementById('uptime');
    const startTime = Date.now() - (Math.random() * 10000000); // Mock uptime
    const uptime = Date.now() - startTime;
    
    const hours = Math.floor(uptime / (1000 * 60 * 60));
    const minutes = Math.floor((uptime % (1000 * 60 * 60)) / (1000 * 60));
    
    uptimeElement.textContent = `${hours}h ${minutes}m`;
}

// Update system status with random values (mock data)
function updateSystemStatus() {
    const stats = [
        { id: 'cpu', min: 20, max: 80 },
        { id: 'ram', min: 30, max: 90 },
        { id: 'temp', min: 45, max: 75, unit: '°C' },
        { id: 'disk', min: 15, max: 50 }
    ];
    
    stats.forEach(stat => {
        const value = stat.min + Math.random() * (stat.max - stat.min);
        const percentage = stat.id === 'temp' ? (value / 80) * 100 : value;
        
        const progressElement = document.getElementById(`${stat.id}-progress`);
        const valueElement = document.getElementById(`${stat.id}-value`);
        
        if (progressElement && valueElement) {
            progressElement.style.width = `${percentage}%`;
            valueElement.textContent = stat.unit ? 
                `${Math.round(value)}${stat.unit}` : 
                `${Math.round(value)}%`;
        }
    });
}

// Export configuration for streaming software
function exportConfig(software) {
    const config = {
        software: software,
        rtmp: currentConfig.rtmp,
        srt: currentConfig.srt,
        device: 'IRLbridge',
        timestamp: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `irlbridge-${software}-config.json`;
    a.click();
    
    URL.revokeObjectURL(url);
    showNotification(`${software} configuration exported!`);
}

// Update device IP (mock function)
function updateDeviceIP() {
    const newIP = prompt('Enter new device IP:', document.getElementById('device-ip').textContent);
    if (newIP && /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(newIP)) {
        document.getElementById('device-ip').textContent = newIP;
        
        // Update URLs with new IP
        currentConfig.rtmp.url = `rtmp://${newIP}:${currentConfig.rtmp.port}/live`;
        currentConfig.srt.url = `srt://${newIP}:9998`;
        
        updateFormValues();
        generateQRCodes();
        showNotification('Device IP updated successfully!');
    } else if (newIP) {
        showNotification('Invalid IP address format!');
    }
}

// Add click handler for device IP
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('device-ip').addEventListener('click', updateDeviceIP);
    document.getElementById('device-ip').style.cursor = 'pointer';
    document.getElementById('device-ip').title = 'Click to change IP address';
});

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey || e.metaKey) {
        switch(e.key) {
            case 's':
                e.preventDefault();
                updateStreamConfig();
                break;
            case 'r':
                e.preventDefault();
                generateQRCodes();
                break;
        }
    }
});

// Touch gestures for mobile
let touchStartY = 0;
document.addEventListener('touchstart', function(e) {
    touchStartY = e.touches[0].clientY;
});

document.addEventListener('touchend', function(e) {
    const touchEndY = e.changedTouches[0].clientY;
    const diff = touchStartY - touchEndY;
    
    // Pull down to refresh (refresh QR codes)
    if (diff < -100) {
        generateQRCodes();
        showNotification('QR codes refreshed!');
    }
});
*/

//on page actually loaded
window.PageRendered = () => {
    setupTabNavigation();
    setupSoftwareTabs();
};