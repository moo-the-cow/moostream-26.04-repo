window.GenerateQrCode = async (streamType, canvasId, text, size) => {
    streamUrl = document.querySelector('.tab-content.active input.streamUrl').value;
    streamKey = document.querySelector('.tab-content.active input.streamKey').value;
    //mediamtx specific
    if(streamUrl.startsWith("srt://"))
    {
        streamUrl = `${streamUrl}?streamid=`;
        streamKey = `publish:${streamKey}`;
    }
    let formattedText = "";
    if(streamType == 0)
    {
        formattedText = await FormatInputForMoblin("irlbridge",`${streamUrl}${streamKey}`);
        document.getElementById("moblin-url").href=formattedText;
    }
    else
    {
        formattedText = await FormatInputForIrlPro(streamUrl, streamKey);
        document.getElementById("irlpro-url").href=formattedText;

    }
    new QRious({
        element: document.getElementById(canvasId),
        size: size,
        value: formattedText
    });
};

window.FormatInputForMoblin = async (streamName, fullIngestUrlIncludingStreamId) => {
    return `moblin://?{"streams":[{"name":"${streamName}","url":"${fullIngestUrlIncludingStreamId}","video":{"codec":"H.265/HEVC"}}]}`;
};
window.FormatInputForIrlPro = async (fullIngestUrlExcludingStreamId, streamid) => {
    return `larix://set/v1?enc[vid][camera]=0&enc[vid][res]=1920x1080&enc[vid][reverse]=false&enc[vid][fps]=30&enc[vid][bitrate]=6000&enc[vid][format]=hevc&enc[vid][keyframe]=2&enc[vid][adaptiveBitrate]=4&enc[vid][adaptiveFps]=0&enc[aud][channels]=2&enc[aud][samples]=48000&enc[aud][awake]=false&conn[][url]=${fullIngestUrlExcludingStreamId}&conn[][name]=stream&conn[][overwrite]=on&conn[][mode]=va&conn[][srtmode]=c&conn[][srtlatency]=2500&conn[][srtmaxbw]=0&conn[][srtstreamid]=${streamid}`;
};